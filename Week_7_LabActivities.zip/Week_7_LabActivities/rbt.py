import tkinter as tk
from tkinter import messagebox
import time

class Node:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.color = 'red'
        self.left = None
        self.right = None
        self.parent = None

class RBTree:
    def __init__(self):
        self.NIL = Node(None, None)
        self.NIL.color = 'black'
        self.NIL.left = self.NIL
        self.NIL.right = self.NIL
        self.NIL.parent = self.NIL
        self.root = self.NIL

    def left_rotate(self, x):
        if x is None or x.right is None:
            return
        y = x.right
        x.right = y.left
        if y.left is not None and y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent is None or x.parent == self.NIL:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def right_rotate(self, x):
        if x is None or x.left is None:
            return
        y = x.left
        x.left = y.right
        if y.right is not None and y.right != self.NIL:
            y.right.parent = x
        y.parent = x.parent
        if x.parent is None or x.parent == self.NIL:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y

    def insert_fixup(self, k):
        while k.parent and k.parent.color == 'red':
            if k.parent.parent is None:
                break
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left if k.parent.parent.left is not None else self.NIL
                if u.color == 'red':
                    u.color = 'black'
                    k.parent.color = 'black'
                    k.parent.parent.color = 'red'
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = 'black'
                    k.parent.parent.color = 'red'
                    self.left_rotate(k.parent.parent)
            else:
                u = k.parent.parent.right if k.parent.parent.right is not None else self.NIL
                if u.color == 'red':
                    u.color = 'black'
                    k.parent.color = 'black'
                    k.parent.parent.color = 'red'
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = 'black'
                    k.parent.parent.color = 'red'
                    self.right_rotate(k.parent.parent)
            if k == self.root:
                break
        self.root.color = 'black'

    def insert(self, name, phone):
        node = Node(name, phone)
        node.left = self.NIL
        node.right = self.NIL
        node.color = 'red'

        parent = None
        current = self.root

        while current != self.NIL:
            if current is None:
                break
            parent = current
            if node.name < current.name:
                current = current.left
            elif node.name > current.name:
                current = current.right
            else:
                current.phone = phone
                return

        node.parent = parent
        if parent == None:
            self.root = node
        elif node.name < parent.name:
            parent.left = node
        else:
            parent.right = node

        if node.parent == None:
            node.color = 'black'
            return

        if node.parent.parent == None:
            return

        self.insert_fixup(node)

    def minimum(self, node):
        if node is None or node == self.NIL:
            return self.NIL
        while node.left != self.NIL:
            node = node.left
        return node

    def transplant(self, u, v):
        if v is None:
            v = self.NIL
        if u.parent is None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def delete_fixup(self, x):
        if x is None or x == self.NIL:
            return
        while x != self.root and x.color == 'black':
            if x.parent is None:
                break
            if x == x.parent.left:
                w = x.parent.right if x.parent.right is not None else self.NIL
                if w.color == 'red':
                    w.color = 'black'
                    x.parent.color = 'red'
                    self.left_rotate(x.parent)
                    w = x.parent.right if x.parent.right is not None else self.NIL
                if (w.left is None or w.left.color == 'black') and (w.right is None or w.right.color == 'black'):
                    w.color = 'red'
                    x = x.parent
                else:
                    if w.right is None or w.right.color == 'black':
                        if w.left is not None:
                            w.left.color = 'black'
                        w.color = 'red'
                        self.right_rotate(w)
                        w = x.parent.right if x.parent.right is not None else self.NIL
                    if w is not None:
                        w.color = x.parent.color
                    x.parent.color = 'black'
                    if w.right is not None:
                        w.right.color = 'black'
                    self.left_rotate(x.parent)
                    x = self.root
            else:
                w = x.parent.left if x.parent.left is not None else self.NIL
                if w.color == 'red':
                    w.color = 'black'
                    x.parent.color = 'red'
                    self.right_rotate(x.parent)
                    w = x.parent.left if x.parent.left is not None else self.NIL
                if (w.right is None or w.right.color == 'black') and (w.left is None or w.left.color == 'black'):
                    w.color = 'red'
                    x = x.parent
                else:
                    if w.left is None or w.left.color == 'black':
                        if w.right is not None:
                            w.right.color = 'black'
                        w.color = 'red'
                        self.left_rotate(w)
                        w = x.parent.left if x.parent.left is not None else self.NIL
                    if w is not None:
                        w.color = x.parent.color
                    x.parent.color = 'black'
                    if w.left is not None:
                        w.left.color = 'black'
                    self.right_rotate(x.parent)
                    x = self.root
        x.color = 'black'

    def delete(self, name):
        z = self.search(self.root, name)
        if z == self.NIL:
            return

        y = z
        y_original_color = y.color
        if z.left == self.NIL:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right if z.right is not None else self.NIL
                if y.right is not None:
                    y.right.parent = y
            self.transplant(z, y)
            y.left = z.left if z.left is not None else self.NIL
            if y.left is not None:
                y.left.parent = y
            y.color = z.color
        if y_original_color == 'black':
            self.delete_fixup(x)

    def search(self, node, name):
        if node is None or node == self.NIL:
            return self.NIL
        if name == node.name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def inorder(self, node, result=None):
        if result is None:
            result = []
        if node != self.NIL and node is not None:
            self.inorder(node.left, result)
            result.append((node.name, node.phone))
            self.inorder(node.right, result)
        return result

class RBTreeVisualizerApp:
    def __init__(self, root):
        self.tree = RBTree()
        self.root = root
        self.root.title("Contact Directory Red-Black Tree")

        frame = tk.Frame(root)
        frame.pack(pady=10)
        tk.Label(frame, text="Name:").grid(row=0, column=0, padx=5)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1, padx=5)
        tk.Label(frame, text="Phone:").grid(row=1, column=0, padx=5)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1, padx=5)
        button_frame = tk.Frame(root)
        button_frame.pack()
        self.insert_btn = tk.Button(button_frame, text="Insert Contact", command=self.insert_contact)
        self.insert_btn.grid(row=0, column=0, padx=5)
        self.search_btn = tk.Button(button_frame, text="Search Contact", command=self.search_contact)
        self.search_btn.grid(row=0, column=1, padx=5)
        self.delete_btn = tk.Button(button_frame, text="Delete Contact", command=self.delete_contact)
        self.delete_btn.grid(row=0, column=2, padx=5)
        self.show_all_btn = tk.Button(button_frame, text="Show All Contacts", command=self.show_all)
        self.show_all_btn.grid(row=0, column=3, padx=5)
        self.benchmark_btn = tk.Button(button_frame, text="Run Benchmark", command=self.benchmark)
        self.benchmark_btn.grid(row=0, column=4, padx=5)

        self.output_text = tk.Text(root, height=10, width=60)
        self.output_text.pack(pady=10)

        self.canvas = tk.Canvas(root, width=800, height=400, bg='white')
        self.canvas.pack(pady=10)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both name and phone number.")
            return
        self.tree.insert(name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated contact: {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter a name to search.")
            return
        node = self.tree.search(self.tree.root, name)
        self.output_text.delete(1.0, tk.END)
        if node != self.tree.NIL:
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\n")
        else:
            self.output_text.insert(tk.END, "Contact not found.")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter a name to delete.")
            return
        self.tree.delete(name)
        messagebox.showinfo("Success", f"Deleted contact (if existed): {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.tree.inorder(self.tree.root)
        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for name, phone in contacts:
                self.output_text.insert(tk.END, f"Name: {name}, Phone: {phone}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree.root == self.tree.NIL:
            return
        start_x = self.canvas.winfo_width() // 2
        start_y = 20
        level_gap = 70
        node_radius = 20
        self._draw_node(self.tree.root, start_x, start_y, self.canvas.winfo_width() // 4, level_gap, node_radius)

    def _draw_node(self, node, x, y, x_offset, level_gap, radius):
        if node is None or node == self.tree.NIL:
            return

        if node.left != self.tree.NIL:
            x_left = x - x_offset
            y_left = y + level_gap

            self.canvas.create_line(x, y, x_left, y_left)
            self._draw_node(node.left, x_left, y_left, x_offset // 2, level_gap, radius)

        if node.right != self.tree.NIL:
            x_right = x + x_offset
            y_right = y + level_gap

            self.canvas.create_line(x, y, x_right, y_right)
            self._draw_node(node.right, x_right, y_right, x_offset // 2, level_gap, radius)

        color = "red" if node.color == 'red' else "black"
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=color)
        display_name = node.name if len(node.name) <= 10 else node.name[:10] + "..."
        text_color = "white" if node.color == 'black' else "black"
        self.canvas.create_text(x, y, text=display_name, fill=text_color)


    def benchmark(self):
        import random
        import string

        self.tree = RBTree()
        N = 1000
        names = [''.join(random.choices(string.ascii_lowercase, k=7)) for _ in range(N)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(N)]

        start = time.time()
        for i in range(N):
            self.tree.insert(names[i], phones[i])
        insert_time = time.time() - start

        search_names = random.sample(names, N // 2) + ['notfoundname'] * (N // 2)
        start = time.time()
        found_count = 0
        for name in search_names:
            node = self.tree.search(self.tree.root, name)
            if node != self.tree.NIL:
                found_count += 1
        search_time = time.time() - start

        delete_names = random.sample(names, 100)
        start = time.time()
        for name in delete_names:
            self.tree.delete(name)
        delete_time = time.time() - start
        result_text = (
            f"Benchmark Results (N={N}):\n"
            f"Insertion time: {insert_time:.4f} seconds\n"
            f"Search time (for {len(search_names)} queries, found {found_count}): {search_time:.4f} seconds\n"
            f"Deletion time (for 100 deletions): {delete_time:.4f} seconds\n"
        )
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, result_text)

        self.draw_tree()

if __name__ == "__main__":
    root = tk.Tk()
    app = RBTreeVisualizerApp(root)
    root.mainloop()